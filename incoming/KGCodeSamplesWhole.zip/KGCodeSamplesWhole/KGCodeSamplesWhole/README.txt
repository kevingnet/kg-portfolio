All information is copy righted and strictly sample. Do not distribute. 

Author: Kevin Guerra

This is a repository of code samples all completely written by me from scratch except
the two projects that have the word New, NewDeviceScheduler and NewEngine. NewDeviceScheduler 
takes after the original and at its core is the same plus the improvements. NewEngine actually
was written from scratch but modeled after the first version.

These are only code samples and not complete projects, you cannot configure and run them, or
understand the system in its entirety by the code, though some documents do explain their
functionality.

Contents:

-1996_Disney_NetworkConnector
  Automatic connector to netware servers worldwide, used by updater (which I wrote from scratch) to copy 
  software updates. A tool for automatic sofware update and deployment.

-1998_Volt_X25Connector
  Network connector using the X25 protocol, for the Telephone switch simulator

-2000_Electrosonic_NewDeviceScheduler
  Application that schedules commands sent to devices as well as react to events by devices and other.
  Devices are video server, switches, other computers, etc..

-2005_HypermediaSystems_InputValidation
  Input validation library and application that can be attached to web inputs and it will automatically work,
  some assembly language, brutally fast.

-2007_DirecTV_redrat
  Drives redrat (infrared transceiver) to send commands to STBs through scripts.

-2008_DirecTV_Ocr
  Full OCR Client/Server (my original idea, now AbbyReader uses it, should have pattented, oh well.) 
  * server receives an image and sends back text
  * client: binarizes image, segments text, the binarization algorithm is based on OTSU's with some improvements 
    in reliability and speed
  * modules for FFT icon recognition and a replacement for FFT using invented algorithm 20% faster and 10% more
    reliable

-2011_Motorola_STB_CloseCaptioning
  Close captioning module redesign for STB, much much faster, smaller code base, with zero memory leaks.

-2013_JakeKnows_NewEngine
  Web system with code generators that adapt from changes to the database schema, schema generator. 

-2015 VMWare_gemini
  Python code base for automating tests for vmware servers. Written from scratch in 4 months, 12kloc replacing 200kloc

-2015 google_babel
  * android screenshot scripting application (designed and written by motorola) user/de4
  * server and security module, Java, GCP app receives screenshots and saves them in the cloud
  * client, Dart, users view screenshots in english and another language side to side and evaluate that the 
    translation is correct and that there aren't any errors and report that to the server

These are two sample test projects I've done that I thought were cool to show, but unrelated to work.
-HiveMapper
-wordfinder
